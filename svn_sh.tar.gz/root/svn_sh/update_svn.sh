#!/bin/bash
update_svn(){
svn update
}
update_svn
