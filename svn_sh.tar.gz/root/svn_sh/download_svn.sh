#!/bin/bash
install_subversion(){
yum -y install subversion
}
download_svn_project(){
svn --username harry --password 123456 co svn://192.168.2.100/ code
}
install_subversion
download_svn_project
