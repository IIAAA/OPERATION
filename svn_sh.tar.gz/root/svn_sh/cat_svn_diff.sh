#!/bin/bash
cat_all_diff(){
svn diff
}
cat_one_diff(){
svn diff $1
}
cat_server_file(){
svn cat svn://192.168.2.100/$2
}
