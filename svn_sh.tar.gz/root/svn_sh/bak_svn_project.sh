#!/bin/bash
bak_svn_project(){
svnadmin dump /var/svn/project > project.bak
}
reload_svn_project(){
svnadmin create /var/svn/project2
svnadmin load /var/svn/project2 < project.bak
}
bak_svn_project
reload_svn_project
