#!/bin/bash
svn_delete_file(){
svn rm test.sh
svn ci -m "xxx"
}
svn_delete_file
