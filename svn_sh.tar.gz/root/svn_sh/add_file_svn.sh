#!/bin/bash
add_svn_new_file(){
svn add test.sh
svn ci -m "test.sh"
}
add_svn_new_file
