#!/bin/bash
cat_repo_imges(){
svn info     svn://192.168.2.100
}
cat_repo_logs(){
svn log     svn://192.168.2.100
}
cat_repo_imges
cat_repo_logs
