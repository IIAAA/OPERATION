#!/bin/bash
install_subversion(){
yum -y install subversion
}
create_project(){
mkdir /var/svn
svnadmin create /var/svn/project
}
import_loacl_file(){
svn import . file:///var/svn/project/ -m "Init Data"
}
conf_create_usersANDpass(){
sed -i '19canon-access = none' /var/svn/project/conf/svnserve.conf
sed -i '20cauth-access = write' /var/svn/project/conf/svnserve.conf
sed -i '27cpassword-db = passwd' /var/svn/project/conf/svnserve.conf
sed -i '34cauthz-db = authz' /var/svn/project/conf/svnserve.conf
}
create_usersandpass(){
sed -i '8aharry = 123456' /var/svn/project/conf/passwd
sed -i '9atom = 123456' /var/svn/project/conf/passwd 
}
create_acl_conf(){
sed -i '32a[/]' /var/svn/project/conf/authz 
sed -i '33aharry = rw' /var/svn/project/conf/authz
sed -i '34atom = rw' /var/svn/project/conf/authz
}
start_svnserver(){
svnserve -d -r /var/svn/project
}
stop_svnserver(){
killall svnserve
}
restart_svnserver(){
killall svnserve
svnserve -d -r /var/svn/project
}
install_subversion
create_project
cd /usr/lib/systemd/system
import_local_file
conf_create_usersANDpass
create_usersandpass
create_acl_conf
start_svnserver
