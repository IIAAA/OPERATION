#!/bin/bash
upload_svn_project(){
svn ci -m "xx"
}
upload_svn_project
