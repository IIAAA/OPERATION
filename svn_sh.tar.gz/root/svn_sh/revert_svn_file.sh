#!/bin/bash
revert_svn_file(){
svn revert $1
}
revert_svn_file
